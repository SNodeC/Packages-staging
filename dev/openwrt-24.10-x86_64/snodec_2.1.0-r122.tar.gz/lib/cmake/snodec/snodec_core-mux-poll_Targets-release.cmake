#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec::core-mux-poll" for configuration "Release"
set_property(TARGET snodec::core-mux-poll APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec::core-mux-poll PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libsnodec-core-mux-poll.so.2.1.0"
  IMPORTED_SONAME_RELEASE "libsnodec-core-mux-poll.so.2"
  )

list(APPEND _cmake_import_check_targets snodec::core-mux-poll )
list(APPEND _cmake_import_check_files_for_snodec::core-mux-poll "${_IMPORT_PREFIX}/lib/libsnodec-core-mux-poll.so.2.1.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
