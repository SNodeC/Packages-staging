#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "snodec-auth::auth-client" for configuration "Release"
set_property(TARGET snodec-auth::auth-client APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(snodec-auth::auth-client PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libauth-client.a"
  )

list(APPEND _cmake_import_check_targets snodec-auth::auth-client )
list(APPEND _cmake_import_check_files_for_snodec-auth::auth-client "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libauth-client.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
